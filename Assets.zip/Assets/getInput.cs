﻿using UnityEngine;
using UnityEngine.SceneManagement;
using System.Collections;
using UnityEngine.UI; // Required when Using UI elements.

public class getInput : MonoBehaviour
{
    public InputField mainInputField;

    public void Start()
    {
        mainInputField = GetComponent<InputField>();
        mainInputField.text = "Enter Text Here...";
    }//Start

    public void Update()
    {
        Debug.Log(mainInputField.text);
        if (Input.GetKeyDown(KeyCode.Return))
        {
            if (mainInputField.text == "UltronUsed:EnergyBlast")
            {
                SceneManager.LoadScene("FightScene1");
            }//if
            if (mainInputField.text == "YoureDeadSpiderMan")
            {
                SceneManager.LoadScene("FightScene2");
            }//if
            if (mainInputField.text == "LikeATurdInTheWind")
            {
                SceneManager.LoadScene("FightScene3");
            }//if
            if (mainInputField.text == "IveNeverSeenThisManInMyLife")
            {
                SceneManager.LoadScene("FightScene4");
            }//if
            if (mainInputField.text == "AsAllThingsShouldBe")
            {
                SceneManager.LoadScene("FightScene5");
            }//if
        }//if
    }//U[date
}//getInput
